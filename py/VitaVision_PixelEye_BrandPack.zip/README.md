# VitaVision - Brand Pack (Option B: Pixel-Eye)

This pack contains SVG assets and a React component for the VitaVision brand.

## Files

- `logo/logo-horizontal-*.svg` — primary logo for headers and nav bars (light/dark).
- `logo/logo-stacked-*.svg` — centered layout for splash/about (light/dark).
- `icon/icon-256.svg`, `icon/icon-512.svg` — app icons.
- `favicon.svg` — SVG favicon (modern browsers supported).
- `social/social-card-1200x630.svg` — Open Graph/Twitter card.
- `colors.css` — CSS variables for brand colors.
- `VitaVisionLogo.tsx` — reusable React component.
- `manifest.webmanifest` — starter PWA manifest (PNG paths are placeholders).

## Color tokens

- Accent gradient: `#22D3EE → #2563EB`
- Ink (text/strokes): `#0F172A`
- Ink inverted: `#FFFFFF`
- Background dark: `#0B1220`

## Usage (React)

```tsx
import VitaVisionLogo from "./VitaVisionLogo";
// In JSX:
<VitaVisionLogo width={200} height={160} aria-hidden />


For the wordmark, pair the icon at left with site text using your app fonts.

Favicon

Modern browsers accept SVG favicons:

Always show details
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="alternate icon" href="/favicon.ico">

Open Graph (social)
Always show details
<meta property="og:image" content="/social/social-card-1200x630.svg">
<meta name="twitter:card" content="summary_large_image">

Clear space & minimum sizes

Clear space: keep at least the height of the center pixel square around the mark.

Minimum sizes: 16px (favicon), 24px (UI icon), 120px width (logo horizontal).

Export PNGs

Use an SVG exporter (e.g. Inkscape) to export 256 and 512 PNG icons:

icons/icon-256.png

icons/icon-512.png

Then update manifest.webmanifest paths if needed.

© VitaVision
