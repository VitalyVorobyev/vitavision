import * as React from "react";

type Props = React.SVGProps<SVGSVGElement> & { dark?: boolean };

/** VitaVision Pixel-Eye logo (Option B) */
export default function VitaVisionLogo({ dark = false, ...props }: Props) {
  const ink = dark ? "#FFFFFF" : "#0F172A";
  const gradId = React.useId();
  return (
    <svg viewBox="0 0 200 160" aria-label="VitaVision" {...props}>
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="256" y2="256">
          <stop offset="0" stopColor="#22D3EE"/><stop offset="1" stopColor="#2563EB"/>
        </linearGradient>
      </defs>
      <g>
        <path d="M16 80 Q96 16 176 80 Q96 144 16 80 Z"
          fill="none" stroke={ink} strokeWidth={12} strokeLinecap="round" strokeLinejoin="round"/>
        <rect x="84" y="68" width="24" height="24" rx="4" fill={`url(#${gradId})`}/>
      </g>
    </svg>
  );
}
